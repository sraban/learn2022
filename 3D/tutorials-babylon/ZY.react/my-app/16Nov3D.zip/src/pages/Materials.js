// exposed components
import React, { useRef } from 'react'

import { GridMaterialExample } from '../babylonjs/Materials/grid-material.stories';

function Materials() {

  return (
    <>
      <GridMaterialExample />
    </>
  );
}


export default Materials;