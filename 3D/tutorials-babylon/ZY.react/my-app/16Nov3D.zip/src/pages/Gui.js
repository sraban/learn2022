// exposed components
import React, { useRef } from 'react'

import { Grid } from '../babylonjs/GUI/grid.stories';

function Gui() {

  return (
    <>
      <Grid />
    </>
  );
}


export default Gui;