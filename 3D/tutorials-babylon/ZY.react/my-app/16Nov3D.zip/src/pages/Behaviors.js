// exposed components
import React, { useRef } from 'react'
import { DragNDrop } from '../babylonjs/Behaviors/dragNdrop.stories';

function Behaviors() {

  return (
    <>
      <DragNDrop />
    </>
  );
}


export default Behaviors;