// exposed components
import React, { useRef } from 'react'

import { GlowLayer } from '../babylonjs/SpecialFX/glow-layer.stories';

function SpecialFX() {

  return (
    <>
      <GlowLayer />
    </>
  );
}


export default SpecialFX;