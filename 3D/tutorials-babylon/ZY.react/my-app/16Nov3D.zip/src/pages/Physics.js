// exposed components
import React, { useRef } from 'react'

import { BouncyPlaygroundStory } from '../babylonjs/Physics/physics.stories';

function Physics() {

  return (
    <>
      <BouncyPlaygroundStory />
    </>
  );
}


export default Physics;