// exposed components
import React, { useRef } from 'react'

import { ColorGrading } from '../babylonjs/PostProcess/imagePostProcess.stories';

function PostProcess() {

  return (
    <>
      <ColorGrading/>
    </>
  );
}


export default PostProcess;