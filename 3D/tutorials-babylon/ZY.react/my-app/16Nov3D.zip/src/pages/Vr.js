// exposed components
import React, { useRef } from 'react'

import { SimpleVR } from '../babylonjs/VR/withVr.stories';

function Vr() {

  return (
    <>
      <SimpleVR />
    </>
  );
}


export default Vr;