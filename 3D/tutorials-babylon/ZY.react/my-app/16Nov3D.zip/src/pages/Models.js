// exposed components
import React, { useRef } from 'react'

import { ModelStory } from '../babylonjs/Models/model.stories';


function Models() {

  return (
    <>
      <ModelStory />
    </>
  );
}


export default Models;