// exposed components
import React, { useRef } from 'react'

import { NonDeclarativeStory } from '../babylonjs/NonDeclarative/nonDeclarative.stories';

function NonDeclarative() {

  return (
    <>
      <NonDeclarativeStory />
    </>
  );
}


export default NonDeclarative;