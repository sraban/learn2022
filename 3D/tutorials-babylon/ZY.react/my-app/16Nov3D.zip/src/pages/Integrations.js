// exposed components
import React, { useRef } from 'react'
import { ChromaJSProps } from '../babylonjs/Integrations/chromaJS.stories';

function Integrations() {

  return (
    <>
      <ChromaJSProps />
    </>
  );
}


export default Integrations;