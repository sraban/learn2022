// exposed components
import React, { useRef } from 'react'

import { Animations } from '../babylonjs/Basic/animation.stories';

function Basic() {

  return (
    <>
      <Animations />
    </>
  );
}


export default Basic;