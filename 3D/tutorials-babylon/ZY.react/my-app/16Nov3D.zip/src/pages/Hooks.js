// exposed components
import React, { useRef } from 'react'
import { RenderHooksStory } from '../babylonjs/Hooks/hooks.stories';
function Hooks() {

  return (
    <>
      <RenderHooksStory />
    </>
  );
}


export default Hooks;