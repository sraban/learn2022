// exposed components
import React, { useRef } from 'react'

import { ProceduralFire } from '../babylonjs/Textures/fire-procedural.stories';

function Textures() {

  return (
    <>
      <ProceduralFire />
    </>
  );
}


export default Textures;