import { Color3, Vector3 } from "@babylonjs/core";
import React, { Suspense, useState, useRef, useEffect } from "react";
import { Model, Engine, Scene, useScene, useBeforeRender } from "react-babylonjs";
import "@babylonjs/inspector";

const Inspector = () => {
    const scene = useScene();
    scene.debugLayer.show();
    return null;
};

function Loadmodels() {
    return (
        <div key="multiModels"  style={{height:'94vh'}}>
            <Engine antialias adaptToDeviceRatio canvasId="multiModels">
                <Scene name="mainScene">
                {/* <arcRotateCamera name="cameraRotate" alpha={Math.PI / 2} beta={Math.PI / 2} radius={13.2432} target={Vector3.Zero()} minZ={0.001}/> */}
                <freeCamera name="camera1" target={ Vector3.Zero() } position={new Vector3(0, 5, -10)} />
                    <hemisphericLight name="light1" intensity={0.7} direction={Vector3.Up()} />
                    <sphere name="sphere1" diameter={2} segments={16} position={new Vector3(-2, 2, 0)} />
                    <box name="box1" size={2} position={new Vector3(2, 2, 0)} />
                    <ground name="ground1" width={6} height={6} subdivisions={2} />
                    {/* <Inspector/> */}
                </Scene>
            </Engine>
        </div>
    );
}
export default Loadmodels;