import React,{ useState } from "react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Link
} from "react-router-dom";
import './App.css';

import Home from './pages/Home'
import Meshes from './pages/Meshes'
import Multimodels from './pages/Multimodels'
import Loadmodels from './pages/Loadmodels'
import Camzooms from './pages/Camzooms'

import Basic from './pages/Basic'
import Hooks from './pages/Hooks'
import Behaviors from './pages/Behaviors'
import Gui from './pages/Gui'
import Integrations from './pages/Integrations'
import Materials from './pages/Materials'
import Models from './pages/Models'
import NonDeclarative from './pages/NonDeclarative'
import Physics from './pages/Physics'
import PostProcess from './pages/PostProcess'
import SpecialFX from './pages/SpecialFX'
import Textures from './pages/Textures'
import Vr from './pages/Vr'

function App() {
  
  const [isDetail, setIsDetail] = useState(false);

  return (
    <Router>
      <div id="menu">
        <ul>
          {!isDetail?
            <span>
              <li><Link to="/">Scene</Link></li>
              <li><Link to="/meshes">Multiple Meshses</Link></li>
              <li><Link to="/multi-models">Multi Models in a scene</Link></li>
              <li><Link to="/load-models">Load Models to scene</Link></li>
              <li><Link to="/cam-zoom">Cam/Zoom</Link></li>
              <li><Link to="/cam-zoom">Animations</Link></li>
              <li onClick={() => setIsDetail(true) }>More...</li>
            </span>:
            <span>
              <li><Link to="/basic">Basic</Link></li>
              <li><Link to="/behaviors">Behaviors</Link></li>
              <li><Link to="/gui">Gui</Link></li>
              <li><Link to="/hooks">Hooks</Link></li>
              <li><Link to="/integrations">Integrations</Link></li>
              <li><Link to="/materials">Materials</Link></li>
              <li><Link to="/models">Models</Link></li>
              <li><Link to="/nonDeclarative">NonDeclarative</Link></li>
              <li><Link to="/physics">Physics</Link></li>
              <li><Link to="/postProcess">PostProcess</Link></li>
              <li><Link to="/specialFX">SpecialFX</Link></li>
              <li><Link to="/textures">Textures</Link></li>
              <li><Link to="/vr">VR</Link></li>
              <li onClick={() => setIsDetail(false) }>...Less</li>
            </span>
          }
        </ul>

        <hr />
        </div>
        <div style={{height: '91vh', padding:0}} className="placeHolderMain">
          <Routes>
            <Route exact path="/" element={<Home />} />
            <Route path="/meshes" element={<Meshes />} />
            <Route path="/multi-models" element={<Multimodels />} />
            <Route path="/load-models" element={<Loadmodels />} />
            <Route path="/cam-zoom" element={<Camzooms />} />
            <Route path="/cam-zoom" element={<Camzooms />} />

            <Route path="/basic" element={<Basic />} />
            <Route path="/behaviors" element={<Behaviors />} />
            <Route path="/gui" element={<Gui />} />
            <Route path="/hooks" element={<Hooks />} />
            <Route path="/integrations" element={<Integrations />} />
            <Route path="/materials" element={<Materials />} />
            <Route path="/models" element={<Models />} />
            <Route path="/nonDeclarative" element={<NonDeclarative />} />
            <Route path="/physics" element={<Physics />} />
            <Route path="/postProcess" element={<PostProcess />} />
            <Route path="/specialFX" element={<SpecialFX />} />
            <Route path="/textures" element={<Textures />} />
            <Route path="/vr" element={<Vr />} />
          </Routes>
        </div>
    </Router>
  );
}

export default App;
