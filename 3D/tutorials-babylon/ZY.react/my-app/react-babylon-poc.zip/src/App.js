import React from "react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Link
} from "react-router-dom";
import './App.css';

import Home from './pages/Home'
import Meshes from './pages/Meshes'
import Multimodels from './pages/Multimodels'
import Loadmodels from './pages/Loadmodels'
import Camzooms from './pages/Camzooms'

function App() {
  return (
    <Router>
      <div id="menu">
        <ul>
          <li>
            <Link to="/">Scene</Link>
          </li>
          <li>
            <Link to="/meshes">Multiple Meshses</Link>
          </li>
          <li>
            <Link to="/multi-models">Multi Models in a scene</Link>
          </li>
          <li>
            <Link to="/load-models">Load Models to scene</Link>
          </li>
          <li>
            <Link to="/cam-zoom">Cam/Zoom</Link>
          </li>
          <li>
            <Link to="/cam-zoom">Animations</Link>
          </li>
        </ul>

        <hr />
        </div>
        <div style={{height: '91vh', padding:0}} className="placeHolderMain">
          <Routes>
            <Route exact path="/" element={<Home />} />
            <Route path="/meshes" element={<Meshes />} />
            <Route path="/multi-models" element={<Multimodels />} />
            <Route path="/load-models" element={<Loadmodels />} />
            <Route path="/cam-zoom" element={<Camzooms />} />
            <Route path="/cam-zoom" element={<Camzooms />} />
          </Routes>
        </div>
    </Router>
  );
}

export default App;
