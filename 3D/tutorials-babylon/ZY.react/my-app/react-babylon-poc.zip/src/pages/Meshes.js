import { Color3, Vector3 } from "@babylonjs/core";
import { ActionManager, SetValueAction } from "@babylonjs/core/Actions";
import React, { Suspense, useState, useRef, useEffect } from "react";
import { Model, Engine, Scene, useScene, useBeforeRender } from "react-babylonjs";
import "@babylonjs/inspector";


const Inspector = () => {
    const scene = useScene();
    scene.debugLayer.show();
    return null;
};



const onModelLoadeds = (model, sceneContext) => {
    // model.meshes.map((row) => {
    //     console.log(row.name);
    // });

    // mesh.actionManager = new ActionManager(mesh._scene);
        // mesh.actionManager.registerAction(
        //     new SetValueAction(
        //         ActionManager.OnPointerOverTrigger,
        //         mesh.material,
        //         "wireframe",
        //         true
        //     )
        // );
        // mesh.actionManager.registerAction(
        //     new SetValueAction(
        //         ActionManager.OnPointerOutTrigger,
        //         mesh.material,
        //         "wireframe",
        //         false
        //     )
        // );
};



function Meshes() {

    const scene = useScene();
    // scene.onBeforeRenderObservable.remove(this.handler);

    useBeforeRender((scene) => {
        console.table(scene);
    });

    // scene.cameras[0].attachControl(canvas)

    // scene.onBeforeRenderObservable.add(() => {
    //     console.log('------');
    // });

    const onMeshPickedCustom = (mesh, scene) => {
        // console.log(scene.meshes);
        if (mesh.name == 'box1') {
            setModel(true);
            // change position and scaling to invisble
        }
    
        if (mesh.name == 'box2') {
            setModel(false);
        }
    };

    useEffect(() => {
        console.log("trigger re-render when transform node is set.");

        return () => {
            if (scene !== null) {
                scene.dispose();
            }
        };

    }, []);



    const [model, setModel] = useState(false);
    const [cam, setCam] = useState(true);
    const [lowerRad, setLowerRad] = useState(0.075);
    const positionInvisible = new Vector3(1000, 1000, 1000);

    return (
        <div key="meshes" style={{ height: '94vh' }}>
            <Engine antialias adaptToDeviceRatio canvasId="meshes">
                <Scene onMeshPicked={onMeshPickedCustom}>
                    {cam ?
                        <arcRotateCamera name="cameraRotate" alpha={Math.PI / 2} beta={Math.PI / 2} radius={lowerRad} target={Vector3.Zero()} minZ={0.001} />
                        : <freeCamera name="cameraFree" position={new Vector3(0.02, 0, 0)} cameraDirection={Vector3.Backward()} />}


                    <hemisphericLight name="light1" intensity={0.7} direction={Vector3.Up()} />

                    <box name={'box1'} position={new Vector3(0.0133, 0.0022, 0.005)} size={0.001} visibility={0}></box>
                    <box name={'box2'} position={new Vector3(-0.015,0.010, 0.009)}  size={0.004} visibility={0}>{/* <standardMaterial  diffuseColor={Color3.Red()} specularColor={Color3.Black()} /> */}</box>
                    

                    
                        <Suspense fallback={<box name="fallback1" position={new Vector3(-2.5, 0, 0)} />}>
                            <Model position={model?new Vector3(-0.015, 0.010, 0):positionInvisible} rootUrl={`https://assets.babylonjs.com/meshes/BoomBox/`} sceneFilename="BoomBox.gltf" onModelLoaded={onModelLoadeds}/>
                        </Suspense>

                        <Suspense fallback={<box name="fallback2" position={new Vector3(2.5, 0, 0)} />}>
                        <Model scaleToDimension="0.1" position={!model?new Vector3(0.02, 0, 0):positionInvisible} rootUrl={`https://assets.babylonjs.com/meshes/`} sceneFilename="both_houses_scene.glb" onModelLoaded={onModelLoadeds} />
                    </Suspense>


                    {/* <Inspector /> */}

                </Scene>
            </Engine>

            <div style={{ position: 'absolute', zIndex: '10000', right: '0', top: '50px' }}>
                <button onClick={() => setModel(!model)} type="button">Model {'' + model}</button>
            </div>


            <div style={{ position: 'absolute', zIndex: '10000', right: '0', top: '70px' }}>
                <button onClick={() => setCam(!cam)} type="button">Camera {'' + cam}</button>
            </div>

            <div style={{ position: 'absolute', zIndex: '10000', right: '0', top: '100px' }}>
                <button onClick={() => setLowerRad(lowerRad + 0.1)} type="button" title={lowerRad}>Zoom(-)</button>
            </div>

            <div style={{ position: 'absolute', zIndex: '10000', right: '0', top: '130px' }}>
                <button onClick={() => setLowerRad(lowerRad ? lowerRad - 0.1 : 0)} type="button" title={lowerRad}>Zoom(+)</button>
            </div>

        </div>
    );
}

export default Meshes;