function Loadmodels() {
  return (
    <div>
      <h2>Loadmodels</h2>
    </div>
  );
}
export default Loadmodels;