import { Color3, Vector3 } from "@babylonjs/core";
import React, { useState, useRef, useEffect } from "react";
import { Engine, Scene, useScene, useBeforeRender } from "react-babylonjs";
import "@babylonjs/inspector";

const rpm = 5;

const Inspector = () => {
    const scene = useScene();
    scene.debugLayer.show();
    return null;
};

function Home() {
    const scene = useScene();
    const transformNodeRef = useRef(null);
    const [_, setReady] = useState(false);

    useBeforeRender((scene) => {
        if (transformNodeRef.current !== null) {
            const deltaTimeInMillis = scene.getEngine().getDeltaTime();
            transformNodeRef.current.rotation.y += (rpm / 60) * Math.PI * 2 * (deltaTimeInMillis / 1000);
        }
    });

    useEffect(() => {
        console.log("trigger re-render when transform node is set.");
        setReady(true);

        return () => {
            if (scene !== null) {
                scene.dispose();
            }
        };

    }, [transformNodeRef.current]);

    return (
        <div  key="home" style={{height:'94vh'}}>
            <Engine antialias adaptToDeviceRatio canvasId='home'>
                <Scene>
                    <arcRotateCamera
                        name="camera1"
                        target={Vector3.Zero()}
                        alpha={4.6704}
                        beta={1.1080}
                        radius={10}
                    />

                    <hemisphericLight
                        name="light1"
                        intensity={0.7}
                        direction={Vector3.Up()}
                    />

                    <box name={'box1'} position={new Vector3(0,0.500,0)}>
                        <standardMaterial  diffuseColor={Color3.Red()} specularColor={Color3.Black()} />
                    </box>

                    <ground name="ground1" width={6} height={6} subdivisions={2} />

                    <transformNode name="transform-node" ref={transformNodeRef}>
                        <ground
                            name="ground2"
                            width={6}
                            height={6}
                            subdivisions={2}
                            position={new Vector3(0, 0, 0)}
                        />
                    </transformNode>
                    <Inspector />
                </Scene>
            </Engine>
        </div>
    );
}

export default Home;