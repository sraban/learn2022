function Camzooms() {
    return (
      <>
        <h2>Camzooms</h2>
      </>
    );
  }
  export default Camzooms;