import { BrowserRouter } from "react-router-dom";
import { render, screen } from '@testing-library/react';
import Home from '../Home';

test('renders Home', () => {
  render(<BrowserRouter><Home /></BrowserRouter>);
  screen.debug();
  expect(2).toBe(2);
});
