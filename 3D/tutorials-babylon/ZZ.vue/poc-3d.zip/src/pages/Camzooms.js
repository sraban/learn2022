function Camzooms() {
    return (
      <div>
        <h2>Camzooms</h2>
      </div>
    );
  }
  export default Camzooms;