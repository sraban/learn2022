import { Color3, Vector3 } from "@babylonjs/core";
import React, { Suspense, useState, useRef, useEffect } from "react";
import { Model, Engine, Scene, useScene, useBeforeRender } from "react-babylonjs";
import "@babylonjs/inspector";

function Meshes() {

    const scene = useScene();
    useEffect(() => {
        console.log("trigger re-render when transform node is set.");

        return () => {
            if (scene !== null) {
                scene.dispose();
            }
        };

    }, []);

    return (
        <div key='uniqueKey1'>
            <Engine canvasId="sample-canvas">
                <Scene>
                    <arcRotateCamera name="camera1" alpha={Math.PI / 2} beta={Math.PI / 2}
                        radius={0.075} target={Vector3.Zero()} minZ={0.001} />
                    <hemisphericLight name="light1" intensity={0.7} direction={Vector3.Up()} />
                    <Suspense
                        fallback={
                            <box
                                name="fallback"
                                position={new Vector3(-2.5, 0, 0)}
                            />
                        }
                    >
                        <Model position={new Vector3(0.02, 0, 0)} rootUrl={`https://assets.babylonjs.com/meshes/BoomBox/`} sceneFilename="BoomBox.gltf" />
                    </Suspense>
                </Scene>
            </Engine>
        </div>
    );
}

export default Meshes;