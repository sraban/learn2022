export interface Result {
  userAnswers: number[];
  elapsedTimes: number[];
}
type Results = Result[];
