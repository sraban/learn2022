export interface Score {
  quizId: string;
  score: number;
  attemptDateTime: Date;
  totalQuestions: number;
}
