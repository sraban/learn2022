export type Answer = number | number[] | string;
