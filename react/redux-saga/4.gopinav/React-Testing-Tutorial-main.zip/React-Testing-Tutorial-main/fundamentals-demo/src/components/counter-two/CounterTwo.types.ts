export type CounterTwoProps = {
  count: number
  handleIncrement?: () => void
  handleDecrement?: () => void
}
