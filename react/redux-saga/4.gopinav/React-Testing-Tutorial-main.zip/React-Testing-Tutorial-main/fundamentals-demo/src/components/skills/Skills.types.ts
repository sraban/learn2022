export type SkillsProps = {
  skills: string[]
}
