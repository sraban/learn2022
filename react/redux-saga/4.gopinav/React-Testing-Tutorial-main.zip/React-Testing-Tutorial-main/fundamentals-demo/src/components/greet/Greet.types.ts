export type GreetProps = {
  name?: string
}
