export type UseCounterProps = {
  initialCount?: number
}
