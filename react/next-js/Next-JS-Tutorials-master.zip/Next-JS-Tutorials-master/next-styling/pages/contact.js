import styles from '../styles/Contact.module.scss'

function Contact() {
  return <div className={styles.highlightscss}>Contact Page</div>
}

export default Contact
