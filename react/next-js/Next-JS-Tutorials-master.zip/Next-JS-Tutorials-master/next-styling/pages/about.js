import styles from '../styles/About.module.scss'

function About() {
  return <div className={styles.highlightscss}>About Page</div>
}

export default About
