function Profile() {
  return <h1>Profile Page</h1>
}

export default Profile
