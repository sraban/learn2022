function Sweater() {
  return <h1>Landing page for Sweaters</h1>
}

export default Sweater
