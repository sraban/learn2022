function PageNotFound() {
  return <h1>404 Page with all the custom styling necessary</h1>
}

export default PageNotFound
