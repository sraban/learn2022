function FirstBlog() {
  return <h1>First blog Page</h1>
}

export default FirstBlog
