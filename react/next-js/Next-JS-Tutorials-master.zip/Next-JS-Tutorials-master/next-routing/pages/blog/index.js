function Blog() {
  return <h1>Blog Page</h1>
}

export default Blog
