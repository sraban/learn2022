function SecondBlog() {
  return <h1>Second blog Page</h1>
}

export default SecondBlog
